node app.js
